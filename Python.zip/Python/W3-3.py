yaş = int(input("Yaşınız: "))
if yaş == 18:
    print("18 iyidir!")
if yaş < 0:
    print("Yok canım, daha neler!...")
if yaş < 18:
    print("Genç bir kardeşimizsin!")
if yaş > 18:
    print("Eh, artık yaş yavaş yavaş kemale eriyor!")
