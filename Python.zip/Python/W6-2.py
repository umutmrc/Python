#quiz
parola = input("parolanız: ")
kontrol = True
for i in parola:
    if parola.count(i) > 1:
        kontrol = False
if kontrol:
    print('Parolanız onaylandı!')
else:
    print('Parolanızda aynı harfi bir kez kullanabilirsiniz!')

kelime = input("Herhangi bir kelime: ")
for harf in kelime:
    print(harf, "harfi", kelime, "kelimesinde", kelime.count(harf), "kez geçiyor!")

#quiz
kelime = input("Herhangi bir kelime: ")
sayaç = ""
for harf in kelime:
    if harf not in sayaç:
        sayaç += harf
for harf in sayaç:
    print(harf, "harfi", kelime, "kelimesinde", kelime.count(harf), "kez geçiyor!")
    
