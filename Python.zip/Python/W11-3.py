import sys
print(sys.path)

sys.path.append('C:\\Python')

print(sys.path)

import sözlük
print(sözlük.ara("kitap"))

sözlük.ekle('araba', 'car')
print(sözlük.ara("araba"))













