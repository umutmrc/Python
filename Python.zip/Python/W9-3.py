sepet = { "makarna": 2, "ekmek": 1, "sigara": 8 }
print("Sepetinizdeki ürünler: ")
print(sepet.keys())
toplam = 0
for fiyat in sepet.values():
    toplam += fiyat
print("Toplam fiyat: {} TL".format(toplam))
