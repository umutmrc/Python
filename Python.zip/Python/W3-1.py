a=int(input("bir sayı girin"))
if a>10:
    print("10dan büyüktür")
if a<10:
    print("10dan küçüktür")
if a==10:
    print("girdiğiniz sayı 10dur")
