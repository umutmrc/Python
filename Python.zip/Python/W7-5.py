liste = ["elma", "armut", "çilek"]
liste.append("erik")
liste = liste + ["erik","elma"]
print(liste)

liste = [1, 2, 3]
for i in [4, 5, 6]:
    liste.append(i)
print(liste)

li1 = [1, 3, 4]
li3= list(li1)
li2 = [10, 11, 12]
li1. append(li2)
print(li1)
li3. extend(li2)
print(li3)


liste = ["elma", "armut", "çilek"]
liste.insert(2, "erik")
print(liste)
liste.insert("tahir")
print(liste)

liste = ["elma", "armut", "çilek"]
liste.remove("elma")
print(liste)

meyveler = ["elma", "armut", "çilek", "kiraz"]


for i in reversed(meyveler):
    print(i)

meyveler.reverse()
print(meyveler)


liste = ["elma", "armut", "çilek"]
liste.pop()
print(liste)
liste.pop(0)
print(liste)

meyveler = ["elma", "armut", "ayva", "kiraz"]
meyveler.sort()
print(meyveler)

sayılar = [1, 0, -1, 4, 10, 3, 6]
sayılar.sort()
print(sayılar)


liste = ["elma", "armut", "çilek"]
print(liste.index("elma"))

liste = ["elma", "armut", "elma", "çilek"]
print(liste.count("elma"))


liste2 = liste.copy()
print(liste2)


liste = [1, 2, 3, 5, 10, 20, 30, 45]
liste.clear()
print(liste)























