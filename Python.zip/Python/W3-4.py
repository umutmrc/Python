ad=input("kullanıcı adı:")
if bool(ad) == True:
    print("hoşgeldin")
else:
    print("boş geçme")
