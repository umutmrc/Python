sözlük = {"kitap" : "book",
          "bilgisayar" : "computer",
          "programlama": "programming"}
def ara(sözcük):
    hata = "sözlükte yok!"
    return sözlük.get(sözcük, hata.format(sözcük))

def ekle(sözcük, anlam):
    sözlük[sözcük] = anlam
    print(sözcük, " kelimesi sözlüğe eklendi!")
