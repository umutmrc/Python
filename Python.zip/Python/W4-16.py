while True:
    sayı = int(input("Bir sayı girin: "))
    if sayı == 0:
        break
    elif sayı < 0:
        pass
    else:
        print(sayı)
