kardiz = "python"
print(kardiz.index("p"))
print(kardiz.index("n"))
#print(kardiz.index("z"))
print(kardiz.find("p"))
print(kardiz.find("n"))
print(kardiz.find("z"))
