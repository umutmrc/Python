a = 1
while a < 11:
    print(a)
    a += 1
