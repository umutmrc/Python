
print("medipol", "myo", "2018", sep=" ", end="\n")

#fonksiyon tanımı
#def fonksiyon_adi(parametre1, parametre2, parametre3, parametre4):
#    (...)

#fonksiyon çagrısı
#fonksiyon_adi(argüman1, argüman2, argüman3, argüman4)
#fonksiyon_adi(parametre1=argüman1, parametre2=argüman2, parametre3=argüman3, parametre4=argüman4)

def kare_bul():
    sayı = 12
    print(sayı,"sayısının karesi", sayı**2, "sayısıdır")

kare_bul()

def karesini_bul(sayı):
    print(sayı,"sayısının karesi", sayı**2, "sayısıdır")

karesini_bul(13)

def maximum(x,y):
    if x > y:
        return x
    else:
        return y
  
max_numara=maximum(10,50)
print("iki sayının en büyüğü", max_numara)

def maximum2(x,y=50):
    if x > y:
        return x
    else:
        return y
max_numara=maximum2(80)
print("iki sayının en büyüğü", max_numara)
max_numara=maximum2(20)
print("iki sayının en büyüğü", max_numara)

#Çoklu değer döndürme
def katlar(x):
    return 2*x,3*x,4*x
x2,x3,x4=katlar(10)
print(x2,x3,x4)


#Değişkenlerin tanım alanları
def yaz():
    text="medipol"
    print(text)

text="myo"
yaz()
print(text)

print("-"*10)

def yaz2():
    global text2
    print(text2)
    text2="medipol"
    print(text2)

text2="myo"
yaz2()
print(text2)

print("-"*10)

#parametrelerin fonksiyon içerisinde değiştirilmesi
#karakter dizileri değiştirilemez bir veri tipidir.

def change(i):
    print(i)
    i="medipol"
    print(i)

i = "myo"
print(i)
change(i)
print(i)

print("-"*10)

#parametrelerin fonksiyon içerisinde değiştirilmesi
#listeler değiştirilebilir bir veri tipidir.

def change2 (s):
    print(s)
    s[0]=12
    print(s)

s = [1,2,3,4]
print(s)
change2(s)
print(s)

##

def fonks(n):
    toplam = 0
    for i in range(n):
        toplam = toplam + i
    return toplam
print (fonks(5))











    
