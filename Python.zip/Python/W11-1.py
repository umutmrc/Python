#modül.fonksiyon

import os
print(os.getcwd())

import sys
print(sys.version)

#import modül_adı as farklı_bir_isim
import subprocess as sp
sp.call('notepad.exe')

#from modül_adı import fonksiyon1, fonksiyon2
from os import getcwd, listdir
print(getcwd())
print(listdir())

#from modül_adı import isim as farklı_isim
from os import listdir as ld
print(ld())

#from modül_adı import *
from sys import *
print(version)








