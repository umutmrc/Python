while True:
    s = input("Bir sayı girin: ")
    if s == "iptal":
        break
    if len(s) <= 3:
        #continue
        pass
    print("En fazla üç haneli bir sayı girebilirsiniz.")
