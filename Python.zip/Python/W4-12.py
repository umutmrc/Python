for i in range(0, 5):
    print(i)

print("-"*10)

for i in range(10):
    print(i)

print("-"*10)

for i in range(0, 10, 2):
    print(i)

print("-"*10)

for i in range(10, 0, -1):
    print(i)
