##Listelerin Ögelerini Degistirmek

kardiz = "medipol"
kardiz = "M" + kardiz[1:]
print(kardiz)

renkler = ["kırmızı", "sarı", "mavi", "yeşil", "beyaz"]
print(renkler)

renkler[0] = "siyah"
print(renkler)

liste = [1, 2, 3]
liste[0:len(liste)] = 5, 6, 7
print(liste)
liste[:] = 8, 9, 10
print(liste)
liste[:] = 4, 5
print(liste)


##Listeye Öge Eklemek

liste = [2, 4, 5, 7]
print(liste + [8])

##Listeleri Birlestirmek

yeniliste=renkler+liste
print(yeniliste)










