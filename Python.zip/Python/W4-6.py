a = 0
while a < 100:
    a += 1
    if a % 2 == 0:
        print(a)
