dizi = "medipol"
print(dizi[0])

nesne = "123456789"
print(int(nesne[1]) * 2)

nesne = "123456789"
sayı = int(nesne[1])
print(sayı * 2)

print(len(dizi))
print(dizi[len(dizi)-1])

print("-"*10)

#print(dizi[len(dizi)])

try:
    print(dizi[len(dizi)])
except IndexError as hata:
    print("orijinal hata mesajı: ", hata)

print("-"*10)

print(dizi[-1])
print(dizi[-2])

print("-"*10)

for i in range(7):
    print(dizi[i])

print("-"*10)

for i in range(len(dizi)):
    print(dizi[i])
