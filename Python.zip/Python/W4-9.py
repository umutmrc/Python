tr_harfler = "şçöğüİı"
parola = input("Parolanız: ")
for karakter in parola:
    if karakter in tr_harfler:
        print("parolada Türkçe karakter kullanılamaz")
