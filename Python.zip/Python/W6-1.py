a = "python programlama dili"
print(a.capitalize())

kardiz = "istanbul"
print(kardiz.capitalize())

kardiz = "istanbul büyükşehir belediyesi"
if kardiz.startswith("i"):
    kardiz = "İ" + kardiz[1:]
kardiz = kardiz.capitalize()
print(kardiz)

a = "python programlama dili"
print(a.title())

kardiz = "Python"
print(kardiz.swapcase())

kardiz = "Beşiktaş Jimnastik Kulübü"
bölünmüş = kardiz.split()
print(bölünmüş)

kardiz = " ".join(bölünmüş)
print(kardiz)
kardiz = "-".join(bölünmüş)
print(kardiz)
kardiz = "".join(bölünmüş)
print(kardiz)

şehir = "Kahramanmaraş"
print(şehir.count("a"))







