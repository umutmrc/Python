sözlük = {}
type(sözlük)
sozluk={"İstanbul" :"34" , "Diyarbakır":"21" , "Isparta":"32"}
siparis_rehberi= {  "Corbaci":"444 44 44",
                    "Pizza"  :"555 55 55",
                    "Kebapcı":"666 66 66" }

kelimeler = {"kitap": "book"}
print(len(kelimeler))

kelimeler = {"kitap": "book", "bilgisayar": "computer"}
print(len(kelimeler))

sözlük = {"kitap" : "book",
          "bilgisayar" : "computer",
          "programlama": "programming",
          "dil" : "language",
          "defter" : "notebook"}

#Sözlük Ögelerine Erismek
#sözlük[sözlük_öğesinin_adı]
print(sözlük["kitap"])

for i in sözlük:
    print(sözlük[i])

sözlük = {"Ahmet Özkoparan": ["İstanbul", "Öğretmen", 34],
          "Mehmet Yağız" : ["Adana", "Mühendis", 40],
          "Seda Bayrak" : ["İskenderun", "Doktor", 30]}

kişiler = {"Ahmet Özkoparan": {"Memleket": "İstanbul",
                                "Meslek" : "Öğretmen",
                                "Yaş" : 34},
            "Mehmet Yağız" : {"Memleket": "Adana",
                            "Meslek" : "Mühendis",
                            "Yaş" : 40},
            "Seda Bayrak" : {"Memleket": "İskenderun",
                            "Meslek" : "Doktor",
                            "Yaş" : 30}}

print(kişiler["Mehmet Yağız"]["Memleket"])
print(kişiler["Seda Bayrak"]["Yaş"])
print(kişiler["Ahmet Özkoparan"]["Meslek"])


#Sözlüklere Öge Eklemek
sözlük = {}
sözlük["Ahmet"] = "Adana"
print(sözlük)
print(sözlük["Ahmet"])











notlar = {}
notlar["Ahmet"] = 45
notlar["Mehmet"] = 77
notlar["Seda"] = 98
notlar["Deniz"] = 95
notlar["Ege"] = 95
notlar["Zeynep"] = 100

#Sözlük Ögeleri Üzerinde Degisiklik Yapmak

notlar = {'Seda': 98, 'Ege': 95, 'Mehmet': 77,
'Zeynep': 100, 'Deniz': 95, 'Ahmet': 45}

notlar["Ahmet"] = 65
print(notlar)














