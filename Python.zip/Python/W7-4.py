alfabe = "abcçdefgğhıijklmnoöprsştuüvyz"
liste = list(alfabe)

liste = []
alfabe = "abcçdefgğhıijklmnoöprsştuüvyz"
for harf in alfabe:
    liste += [harf]
print(liste)

##Listeden Öge Çıkarmak
liste = [1, 5, 3, 2, 9]
del liste[0:2]
print(liste)

##Listeleri Silmek
liste = [1, 5, 3, 2, 9]
del liste
#print(liste)

##Listeleri Kopyalamak
liste1 = ["elma", "armut", "erik"]
liste2 = liste1
liste1[0]="ayva"
print (liste1)
print (liste2)
liste2 = liste1[:]
liste1[0]="şeftali"
print (liste1)
print (liste2)
liste2 = list(liste1)
liste1[0]="kayısı"
print (liste1)
print (liste2)






