print(sorted("kitap"))

print("-"*10)

for i in sorted("kitap"):
    print(i, end="")

print("-"*10)


for i in sorted("çiçek"):
    print(i, end="")

print("-"*10)

import locale
locale.setlocale(locale.LC_ALL, "Turkish_Turkey.1254") #Windows için
#locale.setlocale(locale.LC_ALL, "tr_TR") #GNU/Linux için
print(sorted("çiçek", key=locale.strxfrm))

print("-"*10)


for i in sorted("çiçek", key=locale.strxfrm):
    print(i, end="")

print("\n","-"*10,sep="")

site1 = "www.google.com"
site2 = "www.medipol.com"
site3 = "www.yahoo.com"
site4 = "www.iett.org"
for i in site1, site2, site3, site4:
    print("http://", i, sep="")

print("\n","-"*10,sep="")

for i in site1, site2, site3, site4:
    print("http://", i[4:], sep="")
