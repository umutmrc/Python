#Gömülü fonksiyonlar

#max, min, sum

print(max(3,5,7))

liste = [1, 2, 3]
print(max(liste))

isimler = ['ahmet', 'can', 'mehmet', 'selin', 'abdullah', 'kezban']
print(max(isimler, key=len))

l = [1, 2, 3]
print(sum(l))

l = [1, 2, 3]
print(sum(l,10))
