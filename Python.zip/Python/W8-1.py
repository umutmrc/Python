dosyam = open("D:/deneme.txt", "w")

dosyam.write("medipol myo")

dosyam.close()


dosyam2 = open("D:/deneme2.txt")
print(dosyam2.read())
dosyam.close()

dosyam2 = open("D:/deneme2.txt")
print(dosyam2.readline())
print("-"*10)
print(dosyam2.readline())
print("-"*10)
print(dosyam2.readline())
print("-"*10)
dosyam.close()

dosyam2 = open("D:/deneme2.txt")
print(dosyam2.readlines())






