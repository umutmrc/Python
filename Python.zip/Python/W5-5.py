print(dir(str))

print("*"*50)

print(dir(int))


for i in dir(""):
    if "_" not in i[0]:
        print(i)

print(*enumerate("medipol"))

for i in enumerate("medipol"):
    print(i)

for i in enumerate("medipol",1):
    print(i)

for sıra, metot in enumerate(dir("")):
    print(sıra, metot)

print(help(dir))

harfler = "medipol"
a = 0
while a < len(harfler):
    print(harfler[a], sep="\n")
    a += 1

for harf in harfler:
    print(harf)
