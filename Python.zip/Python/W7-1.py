kardiz = "İstanbul Büyükşehir Belediyesi"
print(kardiz[0])

liste = kardiz.split()
print(liste[0])
print(liste[-1])
print(liste[0:2])

for kelime in liste:
    print(kelime, type(kelime))

diller = ["İngilizce", "Fransızca", "Türkçe", "İtalyanca", "İspanyolca"]
print(len(diller))
liste = ["Ali", "Veli", ["Ayşe", "Nazan", "Zeynep"], 34, 65, 33, 5.6]
print(len(liste))
print(liste[2][0])
yeni_liste = liste[2]
print(yeni_liste)
print(yeni_liste[0])


karakterdizi="medipol"
harf_listesi = list(karakterdizi)
print(harf_listesi)

li = list()
print(li)

liste = range(10)

print(len(liste))











