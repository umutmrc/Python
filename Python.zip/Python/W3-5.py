sayı=int(input("sayı?:"))
if sayı % 2 == 0:
    print("çift")
else:
    print("tek")
