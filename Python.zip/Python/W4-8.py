sayılar = "123456789"
for sayı in sayılar:
    print(int(sayı) * 2)


for i in sayılar:
    if int(i) > 3:
        print(i)
