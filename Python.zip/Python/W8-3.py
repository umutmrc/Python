dosyam2 = open("D:/deneme2.txt")
print(dosyam2.readline())
print("-"*10)
print(dosyam2.readline())
print("-"*10)
dosyam2.seek(0)
print(dosyam2.readline())
print("-"*10)


with open("D:/deneme2.txt", "a") as f:
    f.write("\nmedipol4 myo4\n")

with open("D:/deneme2.txt", "r+") as f:
    veri = f.read()
    f.seek(0) 
    f.write("medipol0 myo0\n"+veri)

with open("D:/deneme2.txt", "r+") as f:
    veri = f.readlines()
    veri.insert(2, "medipol9 myo9\n")
    f.seek(0)
    f.writelines(veri)  #liste tipinde yazar
    #for öğe in veri:
     #   f.write(öğe)    #karakter dizisi yazar













