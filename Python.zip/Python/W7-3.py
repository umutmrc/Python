sayılar = 0
notlar = []
for i in range(10):
    soru="not "+str(i)+": "
    veri = int(input(soru))
    sayılar += veri
    notlar += [veri]
print("Girdiğiniz notlar: ", *notlar)
print("Not ortalamanız: ", sayılar/10)


