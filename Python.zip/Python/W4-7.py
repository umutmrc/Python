harfler = "medipol"
for harf in harfler:
    print(harf)

for h in "myo":
    print(h)
