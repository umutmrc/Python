#keys()

sözlük = {"a": 0,
"b": 1,
"c": 2,
"d": 3}
print(sözlük.keys())

liste = list(sözlük.keys())
kardiz = "".join(sözlük.keys())
print(liste)
print(kardiz)
##for anahtar in sözlük.keys()


#values
print(sözlük.values())
##for değer in sözlük.values()

#items
print(sözlük.items())


for anahtar, değer in sözlük.items():
    print(anahtar,"=",değer)

#get
sorgu="e"    
print(sözlük.get(sorgu, "sözlükte yok"))

#clear
sözlük.clear()
print(sözlük)
##del sözlük

#copy
sözlük = {"a": 0,
"b": 1,
"c": 2,
"d": 3}
yedek_sözlük=sözlük.copy()
sözlük["e"]=4
print(sözlük)
print(yedek_sözlük)









#pop
print("pop")
sözlük.pop("e")
print(sözlük)






















