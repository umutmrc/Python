site = "www.medipol.com"
print(site[4:11])

print(site[12:15])

print(site[0:3])

print("-"*10)

site1 = "www.google.com"
site2 = "www.medipol.com"
site3 = "www.yahoo.com"
site4 = "www.iett.org"
for isim in site1, site2, site3, site4:
    print("site: ", isim[4:-4])


dizi1 = "aaaaaaaaaaaaaaaa!"
dizi2 = "bbbbbbbbbbbbbbbbbbbbbbbbb!"
dizi3 = "ccccccccccccccccccccccccccccc!"
dizi4 = "dddddd!"
dizi5 = "eeeeeeeeeeeeeeeeeeeeeeeee!"

print("-"*10)

for dizi in dizi1, dizi2, dizi3, dizi4, dizi5:
    print(dizi[0:-1])

print("-"*10)

kardiz = "Sana Gül Bahçesi Vadetmedim"
print(kardiz[0:4])
print(kardiz[:4])
print(kardiz[17:27])
print(kardiz[17:])

print("-"*10)

print(kardiz[::-1])

print(kardiz[7:4:-1])

kardiz = "istanbul"
print(kardiz[0:8:1])
print(kardiz[0:8:2])
print(kardiz[::2])
print(kardiz[::-1])
print(kardiz[::-2])

for i in reversed("Sana Gül Bahçesi Vadetmedim"):
    print(i, end="")

